<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Global</label>
    <protected>false</protected>
    <values>
        <field>Default_Out_Year_Uplift_Percent__c</field>
        <value xsi:type="xsd:double">3.0</value>
    </values>
    <values>
        <field>Is_Active__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>Minimum_Out_Year_Uplift_Percent__c</field>
        <value xsi:type="xsd:double">3.0</value>
    </values>
</CustomMetadata>
