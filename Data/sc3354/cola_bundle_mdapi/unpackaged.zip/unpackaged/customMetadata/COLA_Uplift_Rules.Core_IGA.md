<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Core IGA</label>
    <protected>false</protected>
    <values>
        <field>Default_Uplift_Percent__c</field>
        <value xsi:type="xsd:double">4.7</value>
    </values>
    <values>
        <field>Description__c</field>
        <value xsi:type="xsd:string">Core Identity Governance and Administration solutions</value>
    </values>
    <values>
        <field>Effective_End_Date__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Effective_Start_Date__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Is_Active__c</field>
        <value xsi:type="xsd:boolean">true</value>
    </values>
    <values>
        <field>Solution_Category__c</field>
        <value xsi:type="xsd:string">Core IGA</value>
    </values>
</CustomMetadata>
